import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;

public class TestPose {
    public void test(Player player) {
        player.setPose(Pose.SLEEPING, false);
    }
}
