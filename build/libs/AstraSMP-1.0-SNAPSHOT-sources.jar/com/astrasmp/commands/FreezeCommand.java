package com.astrasmp.commands;

import com.astrasmp.model.PlayerProfile;
import com.astrasmp.service.ServiceManager;
import com.astrasmp.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class FreezeCommand implements org.bukkit.command.TabExecutor {
    private final ServiceManager services;

    public FreezeCommand(ServiceManager services) {
        this.services = services;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
        if (!sender.isOp()) {
            sender.sendMessage(TextUtil.color("&cУ вас нет прав!"));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(TextUtil.color("&eИспользование: &f/" + label + " <ник>"));
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage(TextUtil.color("&cИгрок не найден или оффлайн!"));
            return true;
        }

        PlayerProfile profile = services.economy().profile(target.getUniqueId(), target.getName());
        boolean freeze = label.equalsIgnoreCase("freeze");

        profile.setFrozen(freeze);

        if (freeze) {
            TextUtil.send(sender, "&bВы заморозили игрока &f" + target.getName());
            TextUtil.send(target, com.astrasmp.AstraSMPPlugin.getInstance().getConfigManager().getMessage("msg_ba5988", "&b&lВНИМАНИЕ! &cВы были заморожены администратором. Запрещено двигаться и взаимодействовать с миром."));
        } else {
            TextUtil.send(sender, "&aВы разморозили игрока &f" + target.getName());
            TextUtil.send(target, com.astrasmp.AstraSMPPlugin.getInstance().getConfigManager().getMessage("msg_c88f0c", "&a&lВНИМАНИЕ! &aВы были разморожены."));
        }

        return true;
    }

    @Override
    public java.util.List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
        if (args.length == 1) return null;
        return java.util.Collections.emptyList();
    }

}
